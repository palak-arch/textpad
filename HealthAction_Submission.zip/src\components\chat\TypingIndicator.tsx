import { Bot } from "lucide-react";

export function TypingIndicator() {
  return (
    <div className="flex gap-3 animate-message-in">
      {/* Avatar */}
      <div className="flex-shrink-0 w-9 h-9 rounded-full gradient-primary flex items-center justify-center text-primary-foreground shadow-glow">
        <Bot className="w-4 h-4" />
      </div>

      {/* Typing bubble */}
      <div className="bg-card border border-border rounded-2xl rounded-bl-md px-4 py-3 shadow-sm">
        <div className="flex gap-1.5 items-center h-5">
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="w-2 h-2 rounded-full bg-muted-foreground animate-typing-dot"
              style={{ animationDelay: `${i * 0.15}s` }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
