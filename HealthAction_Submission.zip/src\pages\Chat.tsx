import { ChatWindow } from "@/components/chat/ChatWindow";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

import { ErrorBoundary } from "@/components/ui/error-boundary";

export default function Chat() {
    const navigate = useNavigate();

    return (
        <div className="min-h-screen bg-background flex flex-col">
            <div className="container mx-auto px-4 py-6 flex-1 flex flex-col">
                <div className="mb-6">
                    <Button
                        variant="ghost"
                        className="gap-2"
                        onClick={() => navigate("/")}
                    >
                        <ArrowLeft className="w-4 h-4" />
                        Back to Home
                    </Button>
                </div>

                <div className="flex-1 max-w-4xl mx-auto w-full flex flex-col">
                    <div className="h-full">
                        <ErrorBoundary>
                            <ChatWindow />
                        </ErrorBoundary>
                    </div>
                </div>
            </div>
        </div>
    );
}
