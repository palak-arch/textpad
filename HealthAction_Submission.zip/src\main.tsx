import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

window.onerror = function (message, source, lineno, colno, error) {
    const errorDiv = document.createElement("div");
    errorDiv.style.cssText = "position:fixed; top:0; left:0; width:100%; height:100%; background:white; color:red; z-index:9999; padding:20px; overflow:auto;";
    errorDiv.innerHTML = `
    <h3>Application Error</h3>
    <p><strong>Message:</strong> ${message}</p>
    <p><strong>Source:</strong> ${source}:${lineno}:${colno}</p>
    <pre>${error?.stack || "No stack trace"}</pre>
  `;
    document.body.appendChild(errorDiv);
};

try {
    createRoot(document.getElementById("root")!).render(<App />);
} catch (e) {
    console.error("Mount error:", e);
    document.body.innerHTML = `<h1>Mount Error: ${e}</h1>`;
}
