import { useState, useEffect, useCallback } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, MapPin, Navigation } from "lucide-react";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

// Fix Leaflet marker icon issue
import icon from "leaflet/dist/images/marker-icon.png";
import iconShadow from "leaflet/dist/images/marker-shadow.png";

const DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;

// Mock data generator
const generateMockCenters = (lat: number, lng: number) => {
  return Array.from({ length: 5 }).map((_, i) => ({
    id: i,
    name: `Health Center ${String.fromCharCode(65 + i)}`,
    address: `${Math.floor(Math.random() * 100)} Medical Blvd`,
    lat: lat + (Math.random() - 0.5) * 0.05,
    lng: lng + (Math.random() - 0.5) * 0.05,
    phone: `+1 (555) ${Math.floor(Math.random() * 900) + 100}-${Math.floor(Math.random() * 9000) + 1000}`,
    isVaccination: Math.random() > 0.5,
  }));
};

function ChangeView({ center }: { center: [number, number] }) {
  const map = useMap();
  useEffect(() => {
    const current = map.getCenter();
    const zoom = map.getZoom();
    if (Math.abs(current.lat - center[0]) > 1e-6 || Math.abs(current.lng - center[1]) > 1e-6) {
      map.setView(center, zoom, { animate: false });
    }
  }, [center, map]);
  return null;
}

export function HealthCenterLocator() {
  const [searchQuery, setSearchQuery] = useState("");
  const [center, setCenter] = useState<[number, number]>([40.7128, -74.0060]); // NYC default
  const [centers, setCenters] = useState<CenterItem[]>(generateMockCenters(40.7128, -74.0060));
  const [loading, setLoading] = useState(false);

  type OverpassElement = {
    id: number
    lat?: number
    lon?: number
    center?: { lat: number; lon: number }
    tags?: Record<string, string>
  }

  type CenterItem = {
    id: number | string
    name: string
    address: string
    lat: number
    lng: number
    phone?: string
    isVaccination: boolean
  }

  const fetchCenters = useCallback(async (lat: number, lng: number) => {
    try {
      const query = `
        [out:json][timeout:25];
        (
          node["healthcare"="vaccination"](around:5000, ${lat}, ${lng});
          way["healthcare"="vaccination"](around:5000, ${lat}, ${lng});
          node["amenity"="clinic"](around:5000, ${lat}, ${lng});
          node["amenity"="hospital"](around:5000, ${lat}, ${lng});
        );
        out center tags;
      `;
      const res = await fetch("https://overpass-api.de/api/interpreter?data=" + encodeURIComponent(query));
      const json: { elements?: OverpassElement[] } = await res.json();
      const elements: OverpassElement[] = json.elements ?? [];
      const items: CenterItem[] = elements
        .map((el, idx) => {
          const latEl = el.lat ?? el.center?.lat;
          const lonEl = el.lon ?? el.center?.lon;
          const tags = el.tags ?? {};
          if (latEl == null || lonEl == null) return null;
          const addrFull = tags["addr:full"];
          const addrParts = [tags["addr:housenumber"], tags["addr:street"], tags["addr:city"]]
            .filter(Boolean)
            .join(" ");
          const name = tags.name ?? "Vaccination/Health Center";
          const isVaccination =
            tags.healthcare === "vaccination" || (name || "").toLowerCase().includes("vaccination");
          return {
            id: el.id ?? idx,
            name,
            address: (addrFull ?? addrParts) || "Address not available",
            lat: latEl,
            lng: lonEl,
            phone: tags.phone,
            isVaccination,
          } as CenterItem;
        })
        .filter((it): it is CenterItem => it !== null);
      const prioritized: CenterItem[] = items
        .sort((a, b) => (a.isVaccination === b.isVaccination ? 0 : a.isVaccination ? -1 : 1))
        .slice(0, 30);
      setCenters(prioritized.length > 0 ? prioritized : generateMockCenters(lat, lng));
    } catch {
      setCenters(generateMockCenters(lat, lng));
    }
  }, []);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setLoading(true);
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}`
      );
      const data = await response.json();

      if (data && data.length > 0) {
        const newLat = parseFloat(data[0].lat);
        const newLng = parseFloat(data[0].lon);
        setCenter([newLat, newLng]);
        await fetchCenters(newLat, newLng);
      }
    } catch (error) {
      console.error("Error searching location:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleLocateMe = () => {
    if ("geolocation" in navigator) {
      setLoading(true);
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setCenter([latitude, longitude]);
          fetchCenters(latitude, longitude).finally(() => setLoading(false));
        },
        (error) => {
          console.error("Error getting location:", error);
          setLoading(false);
        }
      );
    }
  };

  useEffect(() => {
    fetchCenters(center[0], center[1]);
  }, [center, fetchCenters]);

  const directionsUrl = (lat: number, lng: number) => {
    return `https://www.google.com/maps?q=${lat},${lng}`;
  };

  return (
    <section id="locator" className="py-16 md:py-24 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
            Find Nearby Vaccination Centers
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Search a location or use your current position to find vaccination sites and health centers around you.
          </p>
        </div>

        <div className="max-w-4xl mx-auto bg-card rounded-2xl shadow-xl overflow-hidden border border-border">
          <div className="p-4 border-b border-border bg-card/50 backdrop-blur-sm flex gap-2 flex-col sm:flex-row">
            <form onSubmit={handleSearch} className="flex-1 flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Enter city, zip code, or address..."
                  className="pl-9"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button type="submit" disabled={loading}>
                {loading ? "Searching..." : "Search"}
              </Button>
            </form>
            <Button variant="outline" onClick={handleLocateMe} disabled={loading}>
              <Navigation className="w-4 h-4 mr-2" />
              Use My Location
            </Button>
          </div>

          <div className="h-[400px] md:h-[500px] relative z-0">
            <MapContainer
              center={center}
              zoom={13}
              preferCanvas={false}
              style={{ height: "100%", width: "100%" }}
            >
              <ChangeView center={center} />
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                detectRetina={true}
                crossOrigin={true}
              />
              {centers.map((center) => (
                <Marker key={center.id} position={[center.lat, center.lng]}>
                  <Popup>
                    <div className="p-1">
                      <h3 className="font-bold text-sm mb-1">{center.name}</h3>
                      <p className="text-xs text-muted-foreground mb-1">{center.address}</p>
                      {center.phone && <p className="text-xs text-primary font-medium">{center.phone}</p>}
                      <Button asChild size="sm" variant="link" className="p-0 h-auto text-xs mt-1">
                        <a href={directionsUrl(center.lat, center.lng)} target="_blank" rel="noreferrer">Get Directions</a>
                      </Button>
                    </div>
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
          </div>
        </div>
      </div>
    </section>
  );
}
