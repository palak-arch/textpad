import { Header } from "@/components/landing/Header";
import { Footer } from "@/components/landing/Footer";
import { ChatWindow } from "@/components/chat/ChatWindow";
import { FeatureCard } from "@/components/landing/FeatureCard";
import { StatsSection } from "@/components/landing/StatsSection";
import { HealthCenterLocator } from "@/components/landing/HealthCenterLocator";
import { HealthGuides } from "@/components/landing/HealthGuides";
import { Button } from "@/components/ui/button";
import {
  Stethoscope,
  Syringe,
  Bell,
  Shield,
  MessageCircle,
  Database,
  ArrowRight,
  CheckCircle,
} from "lucide-react";

const features = [
  {
    icon: Stethoscope,
    title: "Symptom Analysis",
    description: "Describe your symptoms and receive AI-powered health guidance with risk assessment and recommended actions.",
    color: "primary" as const,
  },
  {
    icon: Syringe,
    title: "Vaccination Schedules",
    description: "Access age-based vaccination information, get reminders, and find nearby immunization centers.",
    color: "success" as const,
  },
  {
    icon: Bell,
    title: "Outbreak Alerts",
    description: "Receive real-time notifications about disease outbreaks in your area with preventive measures.",
    color: "warning" as const,
  },
  {
    icon: Database,
    title: "Government Data",
    description: "Integrated with official health databases for verified, up-to-date medical information.",
    color: "accent" as const,
  },
];

const howItWorks = [
  {
    step: "01",
    title: "Ask a Question",
    description: "Type or speak your health-related query in natural language",
  },
  {
    step: "02",
    title: "AI Analysis",
    description: "Our NLP engine processes and classifies your intent",
  },
  {
    step: "03",
    title: "Get Guidance",
    description: "Receive personalized health information with risk assessment",
  },
];

import { useNavigate } from "react-router-dom";

export default function Index() {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-24 pb-16 md:pt-32 md:pb-24 gradient-hero overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 -left-32 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
        </div>

        <div className="container mx-auto px-4 relative">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 text-primary rounded-full text-sm font-medium mb-6">
              <Shield className="w-4 h-4" />
              <span>Trusted Health Information</span>
            </div>

            <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
              Your AI Health Assistant for{" "}
              <span className="text-gradient">Disease Awareness</span>
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Get instant, reliable health guidance on symptoms, vaccinations, and disease prevention. Powered by AI and backed by government health data.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button
                variant="hero"
                size="xl"
                className="w-full sm:w-auto"
                onClick={() => navigate("/chat")}
              >
                <MessageCircle className="w-5 h-5" />
                Start Chatting
                <ArrowRight className="w-4 h-4" />
              </Button>
              <Button
                variant="glass"
                size="xl"
                className="w-full sm:w-auto"
                onClick={() => document.getElementById("features")?.scrollIntoView({ behavior: "smooth" })}
              >
                Learn More
              </Button>
            </div>
          </div>

          {/* Trust badges */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground">
            {["24/7 Available", "Multi-language", "Privacy Focused", "Verified Sources"].map(
              (badge) => (
                <div key={badge} className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-success" />
                  <span>{badge}</span>
                </div>
              )
            )}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <StatsSection />
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 md:py-28">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
              Comprehensive Health Support
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              From symptom checking to vaccination reminders, get all the health information you need in one place.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature) => (
              <FeatureCard key={feature.title} {...feature} />
            ))}
          </div>
        </div>
      </section>

      {/* Health Guides Section */}
      <section className="bg-muted/30">
        <HealthGuides />
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-20 md:py-28 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 animate-fade-in-up">
            <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
              How It Works
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Get health guidance in three simple steps
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {howItWorks.map((item, index) => (
              <div key={item.step} className="relative text-center animate-fade-in" style={{ animationDelay: `${index * 150}ms` }}>
                {/* Connector line */}
                {index < howItWorks.length - 1 && (
                  <div className="hidden md:block absolute top-10 left-[60%] w-[80%] h-0.5 bg-gradient-to-r from-primary/50 to-primary/10" />
                )}

                <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl gradient-primary text-primary-foreground font-display font-bold text-2xl shadow-glow mb-6">
                  {item.step}
                </div>
                <h3 className="font-display font-semibold text-xl mb-2 text-foreground">
                  {item.title}
                </h3>
                <p className="text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Health Center Locator Section */}
      <HealthCenterLocator />

      {/* Chat Demo Section */}
      <section id="chat" className="py-20 md:py-28">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
              Try It Now
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Experience our AI-powered health assistant. Ask about symptoms, vaccinations, or health alerts.
            </p>
          </div>

          <div className="max-w-2xl mx-auto">
            <ChatWindow />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-28 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
              Ready to Take Control of Your Health?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Join thousands of users who trust HealthAction for reliable health information and guidance.
            </p>
            <Button
              variant="hero"
              size="xl"
              onClick={() => navigate("/chat")}
            >
              Get Started Free
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
