import { useRef, useEffect, useState, useCallback } from "react";
import { ChatMessage } from "./ChatMessage";
import { ChatInput } from "./ChatInput";
import { TypingIndicator } from "./TypingIndicator";
import { QuickActions } from "./QuickActions";
import { Bot, Sparkles, Volume2, VolumeX, Square, Trash2 } from "lucide-react";
import { useHealthChat } from "@/hooks/useHealthChat";

export function ChatWindow() {
  const { messages, isTyping, sendMessage, clearChat } = useHealthChat();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [ttsEnabled, setTtsEnabled] = useState<boolean>(() => localStorage.getItem("ttsEnabled") === "true");

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const currentUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    const updateVoices = () => {
      setVoices(window.speechSynthesis.getVoices());
    };
    updateVoices();
    window.speechSynthesis.onvoiceschanged = updateVoices;
    return () => {
      window.speechSynthesis.onvoiceschanged = null;
    };
  }, []);

  const speak = useCallback((text: string) => {
    if (!("speechSynthesis" in window)) return;

    window.speechSynthesis.cancel();

    // Pronunciation dictionary for health terms
    const pronunciationMap: Record<string, string> = {
      "WHO": "W.H.O.",
      "WHO's": "W.H.O.'s",
      "AI": "A.I.",
      "A.I.": "A.I.",
      " आयरन ": " Iron ", // Contextual fixes if needed
      " आयरन/फोलिक ": " Iron and Folic ",
      "Iron/Folic": "Iron and Folic",
      "folic": "fo-lic",
      "neonatal": "neo-na-tal",
      "postpartum": "post-par-tum",
      "prenatal": "pre-na-tal",
    };

    // Clean text: remove markdown and apply pronunciation fixes
    let cleanText = text
      .replace(/###/g, "")
      .replace(/\*\*/g, "")
      .replace(/\*/g, "")
      .replace(/!\[.*\]\(.*\)/g, "")
      .replace(/\[.*\]\(.*\)/g, "")
      .replace(/#{1,6}\s/g, "")
      .replace(/[-•]/g, " ") // Replace bullets with pauses/spaces
      .trim();

    // Apply pronunciation map
    Object.entries(pronunciationMap).forEach(([word, phonetic]) => {
      const regex = new RegExp(`\\b${word}\\b`, 'gi');
      cleanText = cleanText.replace(regex, phonetic);
    });

    // Split into sentences to prevent browser timeout/cutoff
    const sentences = cleanText.match(/[^.!?]+[.!?]*/g) || [cleanText];
    let sentenceIndex = 0;

    const speakNextSentence = () => {
      if (sentenceIndex >= sentences.length) return;

      const utter = new SpeechSynthesisUtterance(sentences[sentenceIndex].trim());
      currentUtteranceRef.current = utter;

      const preferredVoices = voices.filter(v =>
        v.lang.startsWith("en") &&
        (v.name.toLowerCase().includes("natural") ||
          v.name.toLowerCase().includes("google") ||
          v.name.toLowerCase().includes("microsoft") ||
          v.name.toLowerCase().includes("premium") ||
          v.name.toLowerCase().includes("siri") ||
          v.name.toLowerCase().includes("enhanced"))
      );

      if (preferredVoices.length > 0) {
        utter.voice = preferredVoices[0];
      } else {
        const enVoices = voices.filter(v => v.lang.startsWith("en"));
        if (enVoices.length > 0) utter.voice = enVoices[0];
      }

      // Slightly faster rate (0.95) for better fluency while remaining clear
      utter.rate = 0.95;
      utter.pitch = 1.0;
      utter.volume = 1.0;
      utter.lang = "en-US";

      utter.onend = () => {
        sentenceIndex++;
        // Reduced delay (50ms) for smoother, more fluent transitions
        setTimeout(() => speakNextSentence(), 50);
      };

      utter.onerror = (event) => {
        console.error("SpeechSynthesis error:", event);
        currentUtteranceRef.current = null;
      };

      window.speechSynthesis.speak(utter);
    };

    speakNextSentence();
  }, [voices]);

  const stopSpeak = useCallback(() => {
    if (!("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
  }, []);

  useEffect(() => {
    if (!ttsEnabled) return;
    if (isTyping) return;
    const last = [...messages].reverse().find((m) => m.role === "assistant");
    if (last && last.content) speak(last.content);
  }, [isTyping, messages, ttsEnabled, speak]);

  useEffect(() => {
    localStorage.setItem("ttsEnabled", ttsEnabled ? "true" : "false");
  }, [ttsEnabled]);

  return (
    <div className="flex flex-col h-[600px] bg-background rounded-2xl border border-border shadow-lg overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-5 py-4 border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="relative">
          <div className="w-10 h-10 rounded-full gradient-primary flex items-center justify-center text-primary-foreground shadow-glow">
            <Bot className="w-5 h-5" />
          </div>
          <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-success rounded-full border-2 border-card" />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-foreground">HealthAction Assistant</h3>
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            AI-powered health guidance
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            className="inline-flex items-center gap-1 text-xs px-3 py-1 rounded-md border hover:bg-destructive/10 hover:text-destructive hover:border-destructive/30 transition-colors"
            onClick={clearChat}
            aria-label="Clear chat history"
            title="Clear chat history"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Clear</span>
          </button>
          <div className="w-px h-4 bg-border mx-1" />
          <button
            className="inline-flex items-center gap-1 text-xs px-3 py-1 rounded-md border hover:bg-muted"
            onClick={() => setTtsEnabled((v) => !v)}
            aria-label="Toggle speech"
          >
            {ttsEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{ttsEnabled ? "Speaking" : "Silent"}</span>
          </button>
          <button
            className="inline-flex items-center gap-1 text-xs px-3 py-1 rounded-md border hover:bg-muted"
            onClick={stopSpeak}
            aria-label="Stop speech"
          >
            <Square className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Stop</span>
          </button>
        </div>
      </div>

      {/* Messages area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center px-4">
            <div className="w-16 h-16 rounded-2xl gradient-primary flex items-center justify-center text-primary-foreground shadow-glow mb-4 animate-float">
              <Bot className="w-8 h-8" />
            </div>
            <h4 className="font-semibold text-lg mb-2">Welcome to HealthAction</h4>
            <p className="text-sm text-muted-foreground mb-6 max-w-sm">
              Get instant guidance on symptoms, vaccinations, and disease awareness. Choose a quick action or type your question.
            </p>
            <QuickActions onSelect={sendMessage} />
          </div>
        ) : (
          <>
            {messages.map((message) => (
              <ChatMessage
                key={message.id}
                content={message.content}
                role={message.role}
                riskLevel={message.riskLevel}
                timestamp={message.timestamp}
                onSpeak={() => speak(message.content)}
              />
            ))}
            {isTyping && <TypingIndicator />}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      {/* Input area */}
      <div className="p-4 border-t border-border bg-card/30 backdrop-blur-sm">
        <ChatInput onSend={sendMessage} disabled={isTyping} />
      </div>
    </div>
  );
}
