import { useEffect, useState, useCallback } from "react"
import { supabase } from "@/integrations/supabase/client"

type Profile = {
  user_id: string
  display_name?: string
  avatar_url?: string
  preferred_theme?: "light" | "dark" | "system"
  preferences?: Record<string, unknown>
  last_seen?: string
}

function storageKey(userId: string) {
  return `profile:${userId}`
}

export function useUserProfile() {
  const [userId, setUserId] = useState<string | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    supabase.auth.getUser().then((res) => {
      const id = res.data.user?.id ?? null
      setUserId(id)
    })
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setUserId(session?.user?.id ?? null)
    })
    return () => {
      sub?.subscription.unsubscribe()
    }
  }, [])

  const load = useCallback(async () => {
    if (!userId) {
      setProfile(null)
      return
    }
    setLoading(true)
    try {
      const local = localStorage.getItem(storageKey(userId))
      if (local) {
        setProfile(JSON.parse(local))
      }
      const { data, error } = await supabase.from("profiles").select("*").eq("user_id", userId).limit(1)
      if (!error && data && data.length > 0) {
        const p = data[0] as Profile
        setProfile(p)
        localStorage.setItem(storageKey(userId), JSON.stringify(p))
      }
    } catch {
      void 0
    } finally {
      setLoading(false)
    }
  }, [userId])

  useEffect(() => {
    load()
  }, [load])

  const save = useCallback(
    async (partial: Partial<Profile>) => {
      if (!userId) return
      const next: Profile = {
        user_id: userId,
        display_name: partial.display_name ?? profile?.display_name,
        avatar_url: partial.avatar_url ?? profile?.avatar_url,
        preferred_theme: partial.preferred_theme ?? profile?.preferred_theme,
        preferences: partial.preferences ?? profile?.preferences,
        last_seen: new Date().toISOString(),
      }
      setProfile(next)
      localStorage.setItem(storageKey(userId), JSON.stringify(next))
      try {
        await supabase.from("profiles").upsert(next, { onConflict: "user_id" })
      } catch {
        void 0
      }
    },
    [userId, profile]
  )

  return { userId, profile, setProfile, save, loading, reload: load }
}
