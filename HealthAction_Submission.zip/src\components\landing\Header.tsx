import { Bot, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { ModeToggle } from "@/components/mode-toggle";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import type { User } from "@supabase/supabase-js";
import { useUserProfile } from "@/hooks/useUserProfile";
import { Select } from "@/components/ui/select";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Link } from "react-router-dom";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [useMagicLink, setUseMagicLink] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const { toast } = useToast();
  const { profile, save } = useUserProfile();
  const [profileOpen, setProfileOpen] = useState(false);
  const [displayNameInput, setDisplayNameInput] = useState<string>("");
  const [avatarInput, setAvatarInput] = useState<string>("");
  const [themeInput, setThemeInput] = useState<"light" | "dark" | "system">("system");

  useEffect(() => {
    supabase.auth.getUser().then((res) => setUser(res.data.user ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });
    return () => {
      sub?.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (profile) {
      setDisplayNameInput(profile.display_name ?? "");
      setAvatarInput(profile.avatar_url ?? "");
      setThemeInput(profile.preferred_theme ?? "system");
    }
  }, [profile]);

  const handleSignIn = async () => {
    if (!email.trim()) {
      toast({ title: "Enter your email", description: "Email is required" });
      return;
    }
    setErrorMsg(null);
    setLoading(true);
    try {
      if (useMagicLink) {
        const { error } = await supabase.auth.signInWithOtp({
          email,
          options: { shouldCreateUser: true, emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        toast({ title: "Check your email", description: "Magic link sent" });
        setAuthOpen(false);
      } else {
        if (!password) {
          toast({ title: "Enter your password", description: "Password is required" });
          setLoading(false);
          return;
        }
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        setUser(data.user ?? null);
        if (data.user?.id) {
          await save({ last_seen: new Date().toISOString() })
        }
        toast({ title: "Signed in", description: "Welcome back" });
        setAuthOpen(false);
      }
    } catch (err) {
      const message =
        err instanceof Error
          ? err.message
          : "Sign-in failed. Check your credentials or confirm your email.";
      setErrorMsg(message);
      toast({ title: "Sign-in failed", description: message });
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async () => {
    if (!email.trim() || !password) {
      toast({ title: "Enter credentials", description: "Email and password required" });
      return;
    }
    setErrorMsg(null);
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signUp({ email, password });
      if (error) throw error;
      setUser(data.user ?? null);
      toast({
        title: "Account created",
        description: "If email confirmation is required, check your inbox.",
      });
      if (data.user?.id) {
        await save({ display_name: email.split("@")[0], last_seen: new Date().toISOString(), preferences: {} })
      }
      setAuthOpen(false);
    } catch (_err) {
      const message =
        _err instanceof Error ? _err.message : "Sign-up failed. Email may be in use.";
      setErrorMsg(message);
      toast({ title: "Sign-up failed", description: message });
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    toast({ title: "Signed out", description: "See you soon" });
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border/50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <a href="/" className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg gradient-primary flex items-center justify-center text-primary-foreground shadow-sm">
              <Bot className="w-5 h-5" />
            </div>
            <span className="font-display font-semibold text-lg text-foreground">
              HealthAction
            </span>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Features
            </a>
            <a href="#how-it-works" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              How It Works
            </a>
            <a href="/chat" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Try Demo
            </a>
            <a href="#locator" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Find Center
            </a>
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <ModeToggle />
            {user ? (
              <>
                <span className="text-sm text-muted-foreground">
                  {profile?.display_name || user.email}
                </span>
                <Link to="/account" className="inline-flex items-center">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={profile?.avatar_url || ""} />
                    <AvatarFallback>
                      {(profile?.display_name || user.email || "U").slice(0, 1).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </Link>
                <Dialog open={profileOpen} onOpenChange={setProfileOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">Profile</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Edit Profile</DialogTitle>
                    </DialogHeader>
                    <div className="grid gap-4 py-2">
                      <div className="grid gap-2">
                        <Label htmlFor="display_name">Display Name</Label>
                        <Input id="display_name" value={displayNameInput} onChange={(e) => setDisplayNameInput(e.target.value)} />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="avatar_url">Avatar URL</Label>
                        <Input id="avatar_url" value={avatarInput} onChange={(e) => setAvatarInput(e.target.value)} />
                      </div>
                      <div className="grid gap-2">
                        <Label>Preferred Theme</Label>
                        <Select value={themeInput} onValueChange={(v) => setThemeInput(v as "light" | "dark" | "system")}>
                          <select className="hidden" />
                        </Select>
                        <div className="flex gap-2">
                          <Button variant={themeInput === "light" ? "secondary" : "outline"} size="sm" onClick={() => setThemeInput("light")}>Light</Button>
                          <Button variant={themeInput === "dark" ? "secondary" : "outline"} size="sm" onClick={() => setThemeInput("dark")}>Dark</Button>
                          <Button variant={themeInput === "system" ? "secondary" : "outline"} size="sm" onClick={() => setThemeInput("system")}>System</Button>
                        </div>
                      </div>
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" onClick={() => setProfileOpen(false)}>Cancel</Button>
                        <Button onClick={async () => {
                          await save({
                            display_name: displayNameInput || undefined,
                            avatar_url: avatarInput || undefined,
                            preferred_theme: themeInput,
                          })
                          setProfileOpen(false)
                          toast({ title: "Profile saved", description: "Your preferences are updated" })
                        }}>Save</Button>
                      </div>
                    </div>
                    <DialogFooter />
                  </DialogContent>
                </Dialog>
                <Button variant="ghost" size="sm" onClick={handleSignOut}>Sign Out</Button>
              </>
            ) : (
              <>
                <Dialog open={authOpen} onOpenChange={setAuthOpen}>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="sm">Sign In</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>{useMagicLink ? "Sign in with Magic Link" : "Sign in"}</DialogTitle>
                    </DialogHeader>
                    <div className="grid gap-4 py-2">
                      <div className="grid gap-2">
                        <Label htmlFor="email">Email</Label>
                        <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                      </div>
                      {!useMagicLink && (
                        <div className="grid gap-2">
                          <Label htmlFor="password">Password</Label>
                          <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
                        </div>
                      )}
                      {errorMsg && <p className="text-sm text-red-600">{errorMsg}</p>}
                      <div className="flex items-center justify-between">
                        <Button variant="outline" onClick={() => setUseMagicLink((v) => !v)}>
                          {useMagicLink ? "Use Password" : "Use Magic Link"}
                        </Button>
                        <div className="flex gap-2">
                          {!useMagicLink && (
                            <Button variant="secondary" onClick={handleSignUp} disabled={loading}>
                              Create Account
                            </Button>
                          )}
                          <Button onClick={handleSignIn} disabled={loading}>
                            {loading ? "Loading..." : useMagicLink ? "Send Link" : "Sign In"}
                          </Button>
                        </div>
                      </div>
                    </div>
                    <DialogFooter />
                  </DialogContent>
                </Dialog>
                <Button variant="hero" size="sm">Get Started</Button>
              </>
            )}
          </div>

          <div className="flex items-center gap-2 md:hidden">
            <ModeToggle />
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <Menu className="w-5 h-5" />
            </Button>
          </div>
        </div>

        <div
          className={cn(
            "md:hidden overflow-hidden transition-all duration-300",
            isMenuOpen ? "max-h-80 pb-4" : "max-h-0"
          )}
        >
          <nav className="flex flex-col gap-2">
            <a href="#features" className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-muted">
              Features
            </a>
            <a href="#how-it-works" className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-muted">
              How It Works
            </a>
            <a href="#chat" className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-muted">
              Try Demo
            </a>
            <a href="#locator" className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-muted">
              Find Center
            </a>
            <div className="flex gap-2 mt-2">
              {user ? (
                <Button variant="ghost" size="sm" className="flex-1" onClick={handleSignOut}>
                  Sign Out
                </Button>
              ) : (
                <Button variant="ghost" size="sm" className="flex-1" onClick={() => setAuthOpen(true)}>
                  Sign In
                </Button>
              )}
              <Button variant="hero" size="sm" className="flex-1">
                Get Started
              </Button>
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
}
