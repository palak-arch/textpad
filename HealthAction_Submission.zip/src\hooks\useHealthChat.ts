import { useState, useCallback, useEffect } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { GoogleGenerativeAI } from "@google/generative-ai";

export type RiskLevel = "low" | "medium" | "high" | "info";

export interface Message {
  id: string;
  content: string;
  role: "user" | "assistant";
  riskLevel?: RiskLevel;
  timestamp: string;
}

const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/health-chat`;

function detectRiskLevel(content: string): RiskLevel {
  const lowerContent = content.toLowerCase();

  if (
    lowerContent.includes("immediate") ||
    lowerContent.includes("emergency") ||
    lowerContent.includes("urgent") ||
    lowerContent.includes("⚠️") ||
    lowerContent.includes("high risk") ||
    lowerContent.includes("seek medical attention immediately")
  ) {
    return "high";
  }

  if (
    lowerContent.includes("monitor") ||
    lowerContent.includes("consult a doctor") ||
    lowerContent.includes("follow-up") ||
    lowerContent.includes("persists") ||
    lowerContent.includes("medium risk")
  ) {
    return "medium";
  }

  if (
    lowerContent.includes("prevention") ||
    lowerContent.includes("preventive") ||
    lowerContent.includes("schedule") ||
    lowerContent.includes("low risk") ||
    lowerContent.includes("recommended")
  ) {
    return "low";
  }

  return "info";
}

export function useHealthChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getUser().then((res) => setUserId(res.data.user?.id ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setUserId(session?.user?.id ?? null);
    });
    return () => {
      sub?.subscription.unsubscribe();
    };
  }, []);

  const storageKey = userId ? `chat:${userId}` : "chat:anon";

  useEffect(() => {
    async function loadMessages() {
      // First try to load from local storage for immediate display
      try {
        const saved = localStorage.getItem(storageKey);
        if (saved) {
          setMessages(JSON.parse(saved));
        }
      } catch {
        /* ignore */
      }

      // If user is logged in, fetch from Supabase to sync across devices
      if (userId) {
        try {
          const { data, error } = await supabase
            .from("chat_messages")
            .select("*")
            .eq("user_id", userId)
            .order("timestamp", { ascending: true });

          if (!error && data && data.length > 0) {
            const remoteMessages: Message[] = data.map((msg) => ({
              id: msg.id,
              content: msg.content,
              role: msg.role as "user" | "assistant",
              riskLevel: (msg.risk_level as RiskLevel) || undefined,
              timestamp: msg.timestamp,
            }));
            // Merge or overwrite? For now, server source of truth seems safer for sync, 
            // but we might want to merge if we have local unsynced messages.
            // Simple approach: Use server data if available.
            setMessages(remoteMessages);
            // Update local storage to match server
            localStorage.setItem(storageKey, JSON.stringify(remoteMessages));
          }
        } catch (error) {
          console.error("Failed to load chat history:", error);
        }
      }
    }

    loadMessages();
  }, [userId, storageKey]);

  const persistLocal = useCallback((msgs: Message[]) => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(msgs));
    } catch {
      /* ignore */
    }
  }, [storageKey]);

  const persistRemote = useCallback(async (newMsgs: Message[]) => {
    if (!userId) return;
    try {
      const rows = newMsgs.slice(-2).map((m) => ({
        user_id: userId,
        id: m.id,
        role: m.role,
        content: m.content,
        risk_level: m.riskLevel ?? null,
        timestamp: new Date().toISOString(),
      }));
      if (rows.length > 0) {
        await supabase.from("chat_messages").insert(rows);
      }
    } catch {
      /* ignore when table doesn't exist */
    }
  }, [userId]);

  const sendMessage = useCallback(async (content: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      role: "user",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => {
      const next = [...prev, userMessage];
      persistLocal(next);
      void persistRemote(next);
      return next;
    });
    setIsTyping(true);

    let assistantContent = "";

    const updateAssistantMessage = (nextChunk: string) => {
      assistantContent += nextChunk;
      setMessages((prev) => {
        const last = prev[prev.length - 1];
        if (last?.role === "assistant") {
          const next = prev.map((m, i) =>
            i === prev.length - 1
              ? { ...m, content: assistantContent, riskLevel: detectRiskLevel(assistantContent) }
              : m
          );
          persistLocal(next);
          return next;
        }
        const next = [
          ...prev,
          {
            id: (Date.now() + 1).toString(),
            content: assistantContent,
            role: "assistant" as const,
            riskLevel: detectRiskLevel(assistantContent),
            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          },
        ];
        persistLocal(next);
        return next;
      });
    };

    try {
      const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error("Missing Gemini API Key");
      }

      const genAI = new GoogleGenerativeAI(apiKey);
      const model = genAI.getGenerativeModel({
        model: "gemini-pro",
        systemInstruction: `You are HealthAction, a friendly and knowledgeable AI health assistant focused on disease awareness, prevention, and vaccination information. Your role is to:
1. **Symptom Guidance**: Help users understand common symptoms and provide general health guidance. Always recommend consulting a healthcare professional for proper diagnosis.
2. **Vaccination Information**: Provide accurate vaccination schedules for different age groups, explain vaccine benefits, and answer common vaccination questions.
3. **Disease Prevention & Awareness**: Share comprehensive information about preventing common diseases. Focus on:
   - **Hygiene**: Hand washing techniques, sanitation, and personal hygiene.
   - **Lifestyle**: Importance of balanced diet, regular exercise, and adequate sleep for immunity.
   - **Environmental**: Mosquito control (for dengue/malaria), clean water, and air quality awareness.
   - **Vaccination**: emphasizing it as a key prevention strategy.
4. **Maternal Health**: Provide professional guidance on:
   - **Prenatal Care**: Importance of regular check-ups, nutrition (iron/folic acid), and danger signs (bleeding, severe pain).
   - **Postpartum Care**: Hygiene, breastfeeding best practices, and newborn warnings (fever, refusing to feed).
5. **Child Health**: Provide information on:
   - **Pediatric Care**: Developmental milestones, nutrition for infants/toddlers, and common childhood illnesses.
   - **Immunization**: Specific childhood vaccination schedules and benefits.
6. **Health Alerts**: Inform about disease outbreaks, preventive measures, and public health recommendations.
Format your responses using clean Markdown structure:
- Use **headers** (###) for major sections.
- Use **bullet points** for lists (vaccine schedules, prevention tips, etc.).
- Use **bold text** for critical terms and warnings.
- Keep responses concise, professional, and action-oriented.
Maintain a formal, professional, and empathetic tone, especially when discussing maternal health.
Important: You are not a doctor. Always emphasize the importance of professional medical consultation.`,
      });

      const chatHistory = messages.map(m => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }]
      }));

      const chat = model.startChat({
        history: chatHistory,
      });

      const result = await chat.sendMessageStream(content);

      for await (const chunk of result.stream) {
        const chunkText = chunk.text();
        if (chunkText) {
          updateAssistantMessage(chunkText);
        }
      }

      // Persist last assistant message remotely (if backend ever works again)
      void persistRemote(messages);
    } catch (error) {
      console.error("Chat error:", error);
      const errorMessage = error instanceof Error ? error.message : "Network or API error";
      toast.error(`Offline: ${errorMessage}`);

      // Fallback to mock response
      const mockResponse = getMockResponse(content);
      let assistantContent = "";

      // Simulate streaming for mock response
      const words = mockResponse.split(" ");
      let wordIndex = 0;

      const streamInterval = setInterval(() => {
        if (wordIndex < words.length) {
          assistantContent += (wordIndex === 0 ? "" : " ") + words[wordIndex];
          setMessages((prev) => {
            // Remove the failed assistant message placeholder if it exists, or update the last one
            // Actually, the previous logic might have left a partial message or no message.
            // Let's safe-guard: if last message is user, add assistant. If assistant, update it.
            const last = prev[prev.length - 1];
            if (last?.role === "assistant") {
              const next = prev.map((m, i) =>
                i === prev.length - 1
                  ? { ...m, content: assistantContent, riskLevel: detectRiskLevel(assistantContent) }
                  : m
              );
              persistLocal(next);
              return next;
            }
            // Use a new ID
            const next = [
              ...prev,
              {
                id: (Date.now() + 1).toString(),
                content: assistantContent,
                role: "assistant" as const,
                riskLevel: detectRiskLevel(assistantContent),
                timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
              },
            ];
            persistLocal(next);
            return next;
          });
          wordIndex++;
        } else {
          clearInterval(streamInterval);
          setIsTyping(false);
          // Toast already handled in catch block
        }
      }, 50);

    } finally {
      // setIsTyping(false); // Handled in mock stream completion or separate
    }
  }, [messages, persistLocal, persistRemote]);

  function getMockResponse(input: string): string {
    const lower = input.toLowerCase();

    if (lower.includes("hello") || lower.includes("hi") || lower.includes("hey")) {
      return "Hello! I am HealthAction, your AI health assistant. How can I help you today?";
    }

    if (lower.includes("symptom") || lower.includes("pain") || lower.includes("ache") || lower.includes("fever")) {
      return "### Symptom Assessment Guidance\n\nPlease be advised that I am an AI assistant and cannot provide a definitive medical diagnosis. For your safety, consider the following points:\n\n*   **Professional Consultation**: It is imperative to consult a qualified healthcare professional for any concerning symptoms.\n*   **Symptom Monitoring**: Document the frequency, severity, and duration of your symptoms.\n*   **Emergency Indicators**: If you experience difficulty breathing, chest pain, or high fever, seek **Immediate Medical Attention**.\n*   **General Care**: Ensure adequate hydration and rest while awaiting professional evaluation.";
    }

    if (lower.includes("vaccin")) {
      return "### Immunization Information & Schedules\n\nVaccinations are essential for public health and individual immunity. Please review these formal guidelines:\n\n*   **Standard Schedules**: Follow local health department recommendations for infant, childhood, and adult boosters.\n*   **Preventive Efficacy**: Vaccines are highly effective at preventing severe diseases such as Measles, Polio, and Influenza.\n*   **Consultation**: Discuss your personal vaccination history with a doctor to ensure comprehensive coverage.\n*   **Verification**: Always obtain vaccinations from accredited health centers.";
    }

    if (lower.includes("alert") || lower.includes("outbreak") || lower.includes("epidemic")) {
      return "### Public Health Alerts & Disease Outbreaks\n\nStaying informed about local health conditions is vital for prevention. Please adhere to these official recommendations:\n\n*   **Official Sources**: Refer to the World Health Organization (WHO) or local health ministries for confirmed outbreak data.\n*   **Preventive Measures**: During outbreaks, increase hand hygiene frequency and use protective measures (e.g., masks or mosquito nets) as advised.\n*   **Report Symptoms**: If you reside in an affected area and develop relevant symptoms, notify health authorities immediately.\n*   **Vaccination Status**: Ensure your immunizations are up-to-date for diseases prevalent in your region.";
    }

    if (lower.includes("child") || lower.includes("pediatric") || lower.includes("baby") || lower.includes("infant")) {
      return "### Pediatric & Child Health Guidelines\n\nSupporting a child's health requires consistent monitoring and care. Please consider the following formal points:\n\n*   **Growth Milestones**: Regularly track physical and cognitive development during pediatric check-ups.\n*   **Nutritional Requirements**: Ensure children receive a balanced diet rich in essential vitamins for growth and immunity.\n*   **Immunization Adherence**: Strict adherence to the pediatric vaccination schedule is critical for disease prevention.\n*   **Hygiene Education**: Teach children proper handwashing techniques and personal hygiene from an early age.\n*   **Safety Monitoring**: Always prioritize a safe environment to prevent injuries and exposure to pollutants.";
    }

    if (lower.includes("center") || lower.includes("clinic") || lower.includes("hospital") || lower.includes("locator")) {
      return "### Nearby Health & Vaccination Centers\n\nI have located several accredited centers near your current location:\n\n*   **City Regional Health Center**: 123 Healthcare Way (Open 24/7)\n*   **Community Vaccination Hub**: 456 Wellness Street (9 AM - 5 PM)\n*   **District General Hospital**: 789 Medical Plaza (Emergency Services)\n\n**Action Required**: You can click the 'Find Nearby Centers' button below to see these on an interactive map, or use the **Health Center Locator** on our landing page for real-time GPS navigation.";
    }

    if (lower.includes("pregnan") || lower.includes("maternal") || lower.includes("birth")) {
      return "### Maternal Health Recommendations\n\nFor optimal maternal and neonatal health outcomes, please adhere to the following professional guidelines:\n\n*   **Prenatal Consultations**: Attend all scheduled prenatal examinations with a healthcare provider.\n*   **Nutritional Supplementation**: Ensure consistent intake of recommended supplements, specifically **Iron and Folic acid**.\n*   **Dietary Regimen**: Maintain a balanced and nutritious diet tailored for pregnancy.\n*   **Vigilant Monitoring**: Monitor for critical danger signs, including severe headaches, vaginal bleeding, or a marked reduction in fetal movement.\n*   **Neonatal Nutrition**: Exclusive breastfeeding is strongly recommended for the initial six months of life.";
    }

    return "I'm currently in offline mode and can only answer basic queries. Please check your connection for full AI capabilities, or consult a doctor for health advice.";
  }

  const clearChat = useCallback(async () => {
    setMessages([]);
    try {
      localStorage.removeItem(storageKey);
      if (userId) {
        await supabase.from("chat_messages").delete().eq("user_id", userId);
      }
      toast.success("Chat history cleared");
    } catch (error) {
      console.error("Failed to clear chat:", error);
      toast.error("Failed to clear chat history");
    }
  }, [userId, storageKey]);

  return { messages, isTyping, sendMessage, clearChat };
}
