const stats = [
  { value: "24/7", label: "Available Support" },
  { value: "50+", label: "Diseases Covered" },
  { value: "10k+", label: "Queries Answered" },
  { value: "99%", label: "Accuracy Rate" },
];

export function StatsSection() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8">
      {stats.map((stat, index) => (
        <div
          key={index}
          className="text-center p-6 rounded-2xl bg-card border border-border"
        >
          <div className="font-display font-bold text-3xl md:text-4xl text-gradient mb-1">
            {stat.value}
          </div>
          <div className="text-sm text-muted-foreground">{stat.label}</div>
        </div>
      ))}
    </div>
  );
}
