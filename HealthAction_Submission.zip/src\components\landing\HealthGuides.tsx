import { Stethoscope, Syringe, AlertCircle, Heart, Baby, MapPin } from "lucide-react";
import { cn } from "@/lib/utils";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

const guides = [
    {
        title: "Symptom Assessment",
        icon: Stethoscope,
        color: "bg-accent/10 text-accent border-accent/20",
        points: [
            "Consult a qualified healthcare professional for any concerning symptoms.",
            "Document the frequency, severity, and duration of your symptoms.",
            "Seek IMMEDIATE attention for difficulty breathing, chest pain, or high fever.",
            "Ensure adequate hydration and rest while awaiting evaluation."
        ]
    },
    {
        title: "Immunization Info",
        icon: Syringe,
        color: "bg-success/10 text-success border-success/20",
        points: [
            "Follow local health department recommendations for all age groups.",
            "Vaccines effectively prevent severe diseases like Measles and Polio.",
            "Discuss your personal vaccination history with a doctor.",
            "Obtain vaccinations only from accredited health centers."
        ]
    },
    {
        title: "Public Health Alerts",
        icon: AlertCircle,
        color: "bg-warning/10 text-warning border-warning/20",
        points: [
            "Refer to WHO or local health ministries for confirmed outbreak data.",
            "Increase hand hygiene frequency during active outbreaks.",
            "Use protective measures (masks, nets) as advised by authorities.",
            "Notify health authorities immediately if you develop relevant symptoms."
        ]
    },
    {
        title: "Maternal Health",
        icon: Heart,
        color: "bg-danger/10 text-danger border-danger/20",
        points: [
            "Attend all scheduled prenatal examinations with a provider.",
            "Ensure consistent intake of Iron and Folic acid supplements.",
            "Maintain a balanced and nutritious diet tailored for pregnancy.",
            "Monitor for danger signs like severe headaches or vaginal bleeding."
        ]
    },
    {
        title: "Child Health",
        icon: Baby,
        color: "bg-primary/10 text-primary border-primary/20",
        points: [
            "Regularly track physical and cognitive developmental milestones.",
            "Ensure children receive a balanced diet rich in essential vitamins.",
            "Strictly adhere to the pediatric vaccination schedule.",
            "Teach children proper handwashing and personal hygiene."
        ]
    },
    {
        title: "Health Resources",
        icon: MapPin,
        color: "bg-secondary text-secondary-foreground border-border",
        points: [
            "Use our integrated locator tool to find nearby facilities.",
            "Prioritize government-approved clinics and hospitals.",
            "Contact local emergency services for life-threatening situations.",
            "Consider telehealth options for non-urgent medical inquiries."
        ]
    }
];

export function HealthGuides() {
    return (
        <section id="health-guides" className="py-20 md:py-28">
            <div className="container mx-auto px-4">
                <div className="text-center mb-16">
                    <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
                        Professional Health Guides
                    </h2>
                    <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                        Access formal, structured guidelines for common health concerns and preventive care.
                    </p>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {guides.map((guide) => (
                        <Card key={guide.title} className="border-border/50 shadow-sm hover:shadow-md transition-shadow">
                            <CardHeader className="pb-3">
                                <CardTitle className="text-xl flex items-center gap-3">
                                    <div className={cn("p-2 rounded-lg border", guide.color)}>
                                        <guide.icon className="w-5 h-5" />
                                    </div>
                                    {guide.title}
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-3">
                                    {guide.points.map((point, i) => (
                                        <li key={i} className="flex gap-2 text-sm text-muted-foreground leading-relaxed">
                                            <span className="text-primary font-bold">•</span>
                                            {point}
                                        </li>
                                    ))}
                                </ul>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </div>
        </section>
    );
}
