import { Stethoscope, Syringe, AlertCircle, Heart, Baby, MapPin } from "lucide-react";
import { cn } from "@/lib/utils";

interface QuickAction {
  id: string;
  label: string;
  icon: React.ElementType;
  query: string;
  color: string;
}

const quickActions: QuickAction[] = [
  {
    id: "symptoms",
    label: "Check Symptoms",
    icon: Stethoscope,
    query: "I want to check my symptoms",
    color: "bg-accent/10 text-accent border-accent/20 hover:bg-accent/20",
  },
  {
    id: "vaccination",
    label: "Vaccination Info",
    icon: Syringe,
    query: "Tell me about vaccination schedules",
    color: "bg-success/10 text-success border-success/20 hover:bg-success/20",
  },
  {
    id: "alerts",
    label: "Health Alerts",
    icon: AlertCircle,
    query: "Are there any disease outbreaks in my area?",
    color: "bg-warning/10 text-warning border-warning/20 hover:bg-warning/20",
  },
  {
    id: "maternal",
    label: "Maternal Health",
    icon: Heart,
    query: "I need information about maternal health",
    color: "bg-danger/10 text-danger border-danger/20 hover:bg-danger/20",
  },
  {
    id: "child",
    label: "Child Health",
    icon: Baby,
    query: "What vaccines does my baby need?",
    color: "bg-primary/10 text-primary border-primary/20 hover:bg-primary/20",
  },
  {
    id: "nearby",
    label: "Nearby Centers",
    icon: MapPin,
    query: "Find vaccination centers near me",
    color: "bg-secondary text-secondary-foreground border-border hover:bg-secondary/80",
  },
];

interface QuickActionsProps {
  onSelect: (query: string) => void;
}

export function QuickActions({ onSelect }: QuickActionsProps) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
      {quickActions.map((action) => {
        const Icon = action.icon;
        return (
          <button
            key={action.id}
            onClick={() => onSelect(action.query)}
            className={cn(
              "flex items-center gap-2 px-3 py-2.5 rounded-xl border text-sm font-medium",
              "transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]",
              action.color
            )}
          >
            <Icon className="w-4 h-4 flex-shrink-0" />
            <span className="truncate">{action.label}</span>
          </button>
        );
      })}
    </div>
  );
}
