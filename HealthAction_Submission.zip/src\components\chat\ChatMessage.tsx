import { cn } from "../../lib/utils";
import ReactMarkdown from "react-markdown";
import { Bot, User, AlertTriangle, CheckCircle, Info, Navigation, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const riskConfig = {
  low: {
    icon: CheckCircle,
    bg: "bg-success/10",
    border: "border-success/30",
    text: "text-success",
    label: "Low Risk",
  },
  medium: {
    icon: Info,
    bg: "bg-warning/10",
    border: "border-warning/30",
    text: "text-warning",
    label: "Medium Risk",
  },
  high: {
    icon: AlertTriangle,
    bg: "bg-danger/10",
    border: "border-danger/30",
    text: "text-danger",
    label: "High Risk",
  },
  info: {
    icon: Info,
    bg: "bg-accent/10",
    border: "border-accent/30",
    text: "text-accent",
    label: "Information",
  },
};

export function ChatMessage({ content, role, riskLevel, timestamp, onSpeak }) {
  const isUser = role === "user";
  const risk = riskLevel ? riskConfig[riskLevel] : null;
  const RiskIcon = risk?.icon;
  const isInteractiveInfo = !isUser && (riskLevel === "info");

  return (
    <div
      className={cn(
        "flex gap-3 animate-message-in",
        isUser ? "flex-row-reverse" : "flex-row"
      )}
    >
      {/* Avatar */}
      <div
        className={cn(
          "flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center",
          isUser
            ? "bg-primary text-primary-foreground"
            : "gradient-primary text-primary-foreground shadow-glow"
        )}
      >
        {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
      </div>

      {/* Message bubble */}
      <div
        className={cn(
          "max-w-[80%] rounded-2xl px-4 py-3 shadow-sm",
          isUser
            ? "bg-primary text-primary-foreground rounded-br-md"
            : "bg-card border border-border rounded-bl-md"
        )}
      >
        {/* Risk indicator for assistant */}
        {!isUser && risk && RiskIcon && (
          <div
            className={cn(
              "flex items-center gap-2 mb-2 px-2 py-1 rounded-lg text-xs font-medium",
              risk.bg,
              risk.border,
              "border"
            )}
          >
            <RiskIcon className={cn("w-3.5 h-3.5", risk.text)} />
            <span className={risk.text}>{risk.label}</span>
          </div>
        )}

        {isUser ? (
          <div className="text-sm leading-relaxed text-primary-foreground">
            <div className="prose prose-sm prose-p:leading-relaxed prose-li:my-1 max-w-none dark:prose-invert">
              <ReactMarkdown>{content}</ReactMarkdown>
            </div>
          </div>
        ) : (
          <Card className="bg-muted/30 border-0 shadow-none w-full">
            <CardHeader className="pb-3 pt-4 px-4">
              <CardTitle className="text-base flex items-center gap-2">
                {risk?.icon && <risk.icon className={cn("w-4 h-4", risk.text)} />}
                {riskLevel === 'high' ? 'Urgent Health Alert' :
                  riskLevel === 'medium' ? 'Health Caution' :
                    riskLevel === 'low' ? 'Health Guidance' :
                      'Information'}
              </CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4 space-y-4">
              <div className="prose prose-sm prose-p:leading-relaxed prose-headings:font-display prose-headings:font-bold prose-li:my-1.5 max-w-none dark:prose-invert text-card-foreground">
                <ReactMarkdown
                  components={{
                    ul: ({ children }) => <ul className="list-disc pl-4 space-y-1 my-3">{children}</ul>,
                    ol: ({ children }) => <ol className="list-decimal pl-4 space-y-1 my-3">{children}</ol>,
                    h3: ({ children }) => <h3 className="text-sm font-bold uppercase tracking-wider text-primary mt-4 mb-2">{children}</h3>,
                    p: ({ children }) => <p className="mb-3 last:mb-0">{children}</p>,
                    strong: ({ children }) => <strong className="font-bold text-foreground">{children}</strong>,
                  }}
                >
                  {content}
                </ReactMarkdown>
              </div>

              {/* Dynamic Action Buttons based on content keywords */}
              {(content.toLowerCase().includes("vaccin") ||
                content.toLowerCase().includes("center") ||
                content.toLowerCase().includes("clinic") ||
                content.toLowerCase().includes("hospital")) && (
                  <div className="flex flex-wrap gap-2 pt-2 border-t border-border/50 mt-4">
                    <Button asChild variant="secondary" size="sm" className="h-8">
                      <a href="#locator" onClick={(e) => {
                        e.preventDefault();
                        document.getElementById("locator")?.scrollIntoView({ behavior: "smooth" });
                      }}>
                        <Navigation className="w-3.5 h-3.5 mr-1" />
                        Find Nearby Centers
                      </a>
                    </Button>
                    <Button asChild variant="outline" size="sm" className="h-8">
                      <a
                        href={`https://www.google.com/search?q=${encodeURIComponent(content.slice(0, 50) + " near me")}`}
                        target="_blank"
                        rel="noreferrer"
                      >
                        <Search className="w-3.5 h-3.5 mr-1" />
                        Google Search
                      </a>
                    </Button>
                  </div>
                )}

              <div className="flex justify-end border-t border-border/50 pt-2">
                <Button variant="ghost" size="sm" onClick={onSpeak} className="h-7 text-xs text-muted-foreground hover:text-foreground">
                  <Navigation className="w-3 h-3 mr-1" />
                  Read Aloud
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {timestamp && (
          <p
            className={cn(
              "text-xs mt-2 opacity-60",
              isUser ? "text-primary-foreground" : "text-muted-foreground"
            )}
          >
            {timestamp}
          </p>
        )}
      </div>
    </div >
  );
}
