import { useEffect, useState } from "react"
import { useUserProfile } from "@/hooks/useUserProfile"
import { useToast } from "@/hooks/use-toast"
import { supabase } from "@/integrations/supabase/client"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { useTheme } from "@/components/theme-provider"

export default function Account() {
  const { profile, save } = useUserProfile()
  const { setTheme } = useTheme()
  const { toast } = useToast()
  const [displayName, setDisplayName] = useState("")
  const [avatarUrl, setAvatarUrl] = useState("")
  const [preferredTheme, setPreferredTheme] = useState<"light" | "dark" | "system">("system")
  const [userId, setUserId] = useState<string | null>(null)
  const [migrating, setMigrating] = useState(false)

  useEffect(() => {
    if (profile) {
      setDisplayName(profile.display_name ?? "")
      setAvatarUrl(profile.avatar_url ?? "")
      setPreferredTheme(profile.preferred_theme ?? "system")
    }
    supabase.auth.getUser().then((res) => setUserId(res.data.user?.id ?? null))
  }, [profile])

  const handleSave = async () => {
    await save({
      display_name: displayName || undefined,
      avatar_url: avatarUrl || undefined,
      preferred_theme: preferredTheme,
    })
    setTheme(preferredTheme)
    toast({ title: "Profile saved", description: "Your account has been updated" })
  }

  const migrateChats = async () => {
    if (!userId) {
      toast({ title: "Not signed in", description: "Sign in to migrate chats" })
      return
    }
    const flagKey = `chat:migrated:${userId}`
    if (localStorage.getItem(flagKey) === "true") {
      toast({ title: "Already migrated", description: "Your chats are already in cloud" })
      return
    }
    const storageKey = `chat:${userId}`
    const raw = localStorage.getItem(storageKey)
    if (!raw) {
      toast({ title: "No local history", description: "Nothing to migrate" })
      return
    }
    setMigrating(true)
    try {
      const msgs: Array<{ id: string; role: "user" | "assistant"; content: string }> = JSON.parse(raw)
      const { data: existing, error } = await supabase
        .from("chat_messages")
        .select("id")
        .eq("user_id", userId)
      if (error) throw error
      const existingRows: { id: string }[] = (existing ?? []) as { id: string }[]
      const existingIds = new Set<string>(existingRows.map((r) => r.id))
      const toInsert = msgs
        .filter((m) => !existingIds.has(m.id))
        .map((m) => ({
          user_id: userId,
          id: m.id,
          role: m.role,
          content: m.content,
          risk_level: null,
          timestamp: new Date().toISOString(),
        }))
      if (toInsert.length > 0) {
        const { error: insertError } = await supabase.from("chat_messages").insert(toInsert)
        if (insertError) throw insertError
      }
      localStorage.setItem(flagKey, "true")
      toast({ title: "Migration complete", description: "Chats moved to cloud" })
    } catch (e) {
      toast({ title: "Migration failed", description: e instanceof Error ? e.message : "Unknown error" })
    } finally {
      setMigrating(false)
    }
  }

  return (
    <div className="min-h-screen bg-background pt-24">
      <div className="container mx-auto px-4 max-w-2xl">
        <div className="flex items-center gap-4 mb-8">
          <Avatar className="h-16 w-16">
            <AvatarImage src={avatarUrl || ""} />
            <AvatarFallback>{(displayName || "U").slice(0, 1).toUpperCase()}</AvatarFallback>
          </Avatar>
          <div>
            <h1 className="font-display text-2xl font-bold">My Account</h1>
            <p className="text-muted-foreground">Manage your profile and data</p>
          </div>
        </div>

        <div className="grid gap-6 bg-card p-6 rounded-2xl border border-border">
          <div className="grid gap-2">
            <Label htmlFor="dn">Display Name</Label>
            <Input id="dn" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="av">Avatar URL</Label>
            <Input id="av" value={avatarUrl} onChange={(e) => setAvatarUrl(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <Label>Preferred Theme</Label>
            <div className="flex gap-2">
              <Button variant={preferredTheme === "light" ? "secondary" : "outline"} onClick={() => setPreferredTheme("light")}>Light</Button>
              <Button variant={preferredTheme === "dark" ? "secondary" : "outline"} onClick={() => setPreferredTheme("dark")}>Dark</Button>
              <Button variant={preferredTheme === "system" ? "secondary" : "outline"} onClick={() => setPreferredTheme("system")}>System</Button>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => window.history.back()}>Back</Button>
            <Button onClick={handleSave}>Save Changes</Button>
          </div>
        </div>

        <div className="grid gap-4 bg-card p-6 rounded-2xl border border-border mt-8">
          <h2 className="font-display text-xl font-semibold">Data & Privacy</h2>
          <p className="text-muted-foreground">Move your local chat history to cloud storage for safe keeping.</p>
          <div>
            <Button onClick={migrateChats} disabled={migrating}>{migrating ? "Migrating..." : "Migrate Chat History"}</Button>
          </div>
        </div>
      </div>
    </div>
  )
}
